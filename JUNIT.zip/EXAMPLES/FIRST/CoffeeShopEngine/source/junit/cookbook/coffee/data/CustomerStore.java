package junit.cookbook.coffee.data;


public interface CustomerStore {

}
