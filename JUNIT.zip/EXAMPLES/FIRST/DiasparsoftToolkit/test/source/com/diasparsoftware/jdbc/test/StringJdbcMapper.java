package com.diasparsoftware.jdbc.test;

import com.diasparsoftware.jdbc.JdbcMapper;


public class StringJdbcMapper extends JdbcMapper {

}
