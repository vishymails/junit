package com.diasparsoftware.store;

public class DataMakesNoSenseException extends DataStoreException {
    public DataMakesNoSenseException(String description) {
        super(description);
    }
}
