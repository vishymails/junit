package com.diasparsoftware.java.util;


public interface Selector {
    boolean accept(Object object);
}
