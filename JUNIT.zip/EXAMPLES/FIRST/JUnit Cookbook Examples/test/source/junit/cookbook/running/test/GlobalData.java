package junit.cookbook.running.test;


public class GlobalData {
    public static boolean calledMe = false;
}
