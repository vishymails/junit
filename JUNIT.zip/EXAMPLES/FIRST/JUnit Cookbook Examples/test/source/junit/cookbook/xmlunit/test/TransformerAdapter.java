package junit.cookbook.xmlunit.test;

import java.util.Properties;

import javax.xml.transform.*;


public class TransformerAdapter extends Transformer {

    public void clearParameters() {
        // TODO Auto-generated method stub

    }

    public Properties getOutputProperties() {
        // TODO Auto-generated method stub
        return null;
    }

    public void setOutputProperties(Properties oformat)
        throws IllegalArgumentException {
        // TODO Auto-generated method stub

    }

    public ErrorListener getErrorListener() {
        // TODO Auto-generated method stub
        return null;
    }

    public void setErrorListener(ErrorListener listener)
        throws IllegalArgumentException {
        // TODO Auto-generated method stub

    }

    public URIResolver getURIResolver() {
        // TODO Auto-generated method stub
        return null;
    }

    public void setURIResolver(URIResolver resolver) {
        // TODO Auto-generated method stub

    }

    public Object getParameter(String name) {
        // TODO Auto-generated method stub
        return null;
    }

    public void setParameter(String name, Object value) {
        // TODO Auto-generated method stub

    }

    public String getOutputProperty(String name)
        throws IllegalArgumentException {
        // TODO Auto-generated method stub
        return null;
    }

    public void setOutputProperty(String name, String value)
        throws IllegalArgumentException {
        // TODO Auto-generated method stub

    }

    public void transform(Source xmlSource, Result outputTarget)
        throws TransformerException {
        // TODO Auto-generated method stub

    }

}
