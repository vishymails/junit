public class FloatingPointArithmeticDemo {
    public static void main(String[] args) {
        for (float i = 0.0f; i != 1.0f; i += 0.1f);
        System.out.println("Done.");
    }
}
