package junit.cookbook.essays;

import java.io.File;


public class RequestProcessor {
    public void process(File[] files) {
    }
}
