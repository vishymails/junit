package junit.cookbook.common;

public class ShapeMaker {
    public Square makeSquare(double sideLength) {
        return new Square(sideLength);
    }
}
