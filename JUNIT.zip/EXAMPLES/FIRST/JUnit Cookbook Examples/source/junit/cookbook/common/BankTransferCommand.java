/*
 * Created on May 3, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package junit.cookbook.common;

import junit.cookbook.util.Money;

/**
 * @author jbrains
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class BankTransferCommand {

    public void setSourceAccountId(String string) {
        // TODO Auto-generated method stub
        
    }

    public void setTargetAccountId(String string) {
        // TODO Auto-generated method stub
        
    }

    public void setAmount(Money money) {
        // TODO Auto-generated method stub
        
    }

    public boolean isReadyToExecute() {
        // TODO Auto-generated method stub
        return false;
    }

}
