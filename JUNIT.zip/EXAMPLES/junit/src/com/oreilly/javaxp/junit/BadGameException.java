package com.oreilly.javaxp.junit;

/**
 * @author Eric M. Burke
 * @version $Id: BadGameException.java,v 1.1 2002/08/17 03:15:39 jepc Exp $
 */
public class BadGameException extends Exception {
    public BadGameException(String s) {
        super(s);
    }
}
