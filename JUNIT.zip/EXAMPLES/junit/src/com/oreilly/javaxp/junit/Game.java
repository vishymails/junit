package com.oreilly.javaxp.junit;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Eric M. Burke
 * @version $Id: Game.java,v 1.1 2002/08/17 03:15:40 jepc Exp $
 */
public class Game {
    private Map ships = new HashMap();

    public Game() throws BadGameException {
    }

    public void shutdown() {
        // dummy method
    }

    public synchronized Ship createFighter(String fighterId) {
        Ship s = (Ship) this.ships.get(fighterId);
        if (s == null) {
            s = new Ship(fighterId);
            this.ships.put(fighterId, s);
        }
        return s;
    }

    public boolean isPlaying() {
        return false;
    }
}
