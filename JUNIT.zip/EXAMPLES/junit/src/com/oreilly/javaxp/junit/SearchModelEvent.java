package com.oreilly.javaxp.junit;

import java.util.EventObject;
import java.util.List;

/**
 * @author Eric M. Burke
 * @version $Id: SearchModelEvent.java,v 1.1 2002/09/02 16:47:59 jepc Exp $
 */
public class SearchModelEvent extends EventObject {
    private List searchResult;

    public SearchModelEvent(SearchModel searchModel, List searchResult) {
        super(searchModel);
        this.searchResult = searchResult;
    }

    public SearchModel getSearchModel() {
        return (SearchModel) getSource();
    }

    public List getSearchResult() {
        return this.searchResult;
    }
}
