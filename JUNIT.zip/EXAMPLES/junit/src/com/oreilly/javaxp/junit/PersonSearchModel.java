package com.oreilly.javaxp.junit;

import java.util.List;
import java.util.ArrayList;

/**
 * @author Eric M. Burke
 * @version $Id: PersonSearchModel.java,v 1.1 2002/09/02 16:47:59 jepc Exp $
 */
public class PersonSearchModel implements SearchModel {
    private Person eric = new Person("Eric", "Burke");
    private Person jen = new Person("Jennifer", "Burke");
    private Person tanner = new Person("Tanner", "Burke");
    private Person aidan = new Person("Aidan", "Burke");


    public void search(Object searchCriteria, SearchModelListener listener) {
        new Searcher(searchCriteria, listener).start();
    }


    public List search(Object searchCriteria) {
        return dummySearch(searchCriteria);
    }

    private List dummySearch(Object searchCriteria) {
        if ("*".equals(searchCriteria)) {
            List results = new ArrayList();
            results.add(this.eric);
            results.add(this.jen);
            results.add(this.tanner);
            results.add(this.aidan);
            return results;
        } else if ("eric".equals(searchCriteria)) {
            List results = new ArrayList();
            results.add(this.eric);
            return results;
        }
        return null;
    }

    class Searcher extends Thread {
        private Object searchCriteria;
        private SearchModelListener listener;

        Searcher(Object searchCriteria, SearchModelListener listener) {
            this.searchCriteria = searchCriteria;
            this.listener = listener;
        }

        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            this.listener.searchFinished(new SearchModelEvent(
                    PersonSearchModel.this,
                    dummySearch(this.searchCriteria)));
        }
    }
}
