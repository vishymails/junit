package com.oreilly.javaxp.junit;

/**
 * @author Eric M. Burke
 * @version $Id: Ship.java,v 1.1 2002/08/17 03:15:40 jepc Exp $
 */
public class Ship {
    private String id;

    public Ship(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }
}
