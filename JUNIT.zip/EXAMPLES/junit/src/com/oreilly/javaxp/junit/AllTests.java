package com.oreilly.javaxp.junit;

import junit.framework.*;

/**
 * Runs all test suites in the current package and sub-packages.
 */
public class AllTests extends TestCase {
    public AllTests(String name) {
        super(name);
    }

    /**
     * @return a suite containing all tests in this package and subpackages.
     */
    public static Test suite() {
        TestSuite suite = new TestSuite();

        // add tests from the current directory
        suite.addTest(new TestSuite(TestGame.class));
        suite.addTest(new TestSuite(TestPerson.class));
        suite.addTest(new TestSuite(TestPersonEditorPanel.class));

        // only test subdirectories if a system property is true
        if ("true".equals(System.getProperty("test.subdirs"))) {
            // add AllTests from any sub-packages
            suite.addTest(com.oreilly.javaxp.junit.sub.AllTests.suite());
            // suite.addTest(...) // continue for other sub-packages
        }

        return suite;
    }
}
