package com.oreilly.javaxp.junit;

import java.util.List;

/**
 * @author Eric M. Burke
 * @version $Id: SearchModel.java,v 1.1 2002/09/02 16:47:59 jepc Exp $
 */
public interface SearchModel {
    void search(Object searchCriteria, SearchModelListener listener);
    List search(Object searchCriteria);
}
