package com.oreilly.javaxp.junit;

import java.util.EventListener;

/**
 * @author Eric M. Burke
 * @version $Id: SearchModelListener.java,v 1.1 2002/09/02 16:47:59 jepc Exp $
 */
public interface SearchModelListener extends EventListener {
    void searchFinished(SearchModelEvent evt);
}
